const express = require('express');
const router = express.Router();
const Order = require('../models/order.model'); // Import the Order model

// Get historical orders
router.get('/', async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 }); // Sort by most recent
    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch historical orders', error });
  }
});

module.exports = router;