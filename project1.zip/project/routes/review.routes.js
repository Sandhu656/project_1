const express = require('express');
const router = express.Router();
const Review = require('../models/review.model');

// Add a review
router.post('/', async (req, res) => {
  try {
    const newReview = new Review(req.body);
    const savedReview = await newReview.save();
    res.status(201).json(savedReview);
  } catch (error) {
    res.status(500).json({ message: 'Failed to add review', error });
  }
});

// Get reviews for a specific item
router.get('/:itemId', async (req, res) => {
  try {
    const reviews = await Review.find({ itemId: req.params.itemId }).sort({ createdAt: -1 });
    res.status(200).json(reviews);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch reviews', error });
  }
});

// Like a review
router.patch('/:reviewId/like', async (req, res) => {
  try {
    const updatedReview = await Review.findByIdAndUpdate(
      req.params.reviewId,
      { $inc: { likes: 1 } },
      { new: true }
    );
    res.status(200).json(updatedReview);
  } catch (error) {
    res.status(500).json({ message: 'Failed to like review', error });
  }
});

module.exports = router;