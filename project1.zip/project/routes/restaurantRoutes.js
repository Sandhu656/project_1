const express = require('express');
const { addToDecision } = require('../controllers/restaurantController'); // Import the function
const {
  getPendingRestaurants,
  approveRestaurant,
  rejectRestaurant
} = require('../controllers/restaurantController');
const router = express.Router();

// Route to add restaurant details to the decision table
router.post('/decision', addToDecision);
// Fetch all pending restaurants
router.get('/decision', getPendingRestaurants);

// Approve a restaurant
router.patch('/approve/:id', approveRestaurant);

// Reject a restaurant
router.delete('/reject/:id', rejectRestaurant);



const Restaurant = require('../models/restaurantModel'); // Include your restaurant model



 // Sign-in Route
router.post('/signin', async (req, res) => {
  const { restaurantName, mailId, password } = req.body;

  try {
    // Find the restaurant by restaurantName, mailId, and password
    const restaurant = await Restaurant.findOne({ restaurantName, mailId, password });

    if (restaurant) {
      res.status(200).json({ message: 'Sign-in successful', restaurant });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Error during sign-in:', error);
    res.status(500).json({ message: 'Server error', error });
  }
});


module.exports = router;