const express = require('express');
const router = express.Router();
const Order = require('../models/orderModel'); // Assuming you have an order model

// Route to fetch historical orders for a user
router.get('/history', async (req, res) => {
  const { customerId } = req.query;

  try {
    const orders = await Order.find({ customerId }).populate('foodItems'); // Assuming foodItems is an array of references
    res.status(200).json({ orders });
  } catch (error) {
    console.error('Error fetching historical orders:', error);
    res.status(500).json({ message: 'Failed to fetch historical orders' });
  }
});

module.exports = router;