import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Order {
  userId: string;
  foodItems: { name: string; quantity: number }[];
  createdAt?: string;
}

@Injectable({
  providedIn: 'root',
})
export class OrderService {
  private historicalOrdersUrl = 'http://localhost:3000/api/historical-orders';
  private popularFoodsUrl = 'http://localhost:3000/api/popular-foods';

  constructor(private http: HttpClient) {}

  // Fetch historical orders
  getHistoricalOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(this.historicalOrdersUrl);
  }

  // Fetch popular foods
  getPopularFoods(): Observable<{ _id: string; totalOrders: number }[]> {
    return this.http.get<{ _id: string; totalOrders: number }[]>(this.popularFoodsUrl);
  }
}