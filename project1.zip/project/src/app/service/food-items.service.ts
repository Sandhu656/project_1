import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface FoodItem {
  name: string;
  category: string;
  restaurant: string;
  tags: string[];
}

@Injectable({
  providedIn: 'root', // Makes the service available across the application
})
export class FoodService {
  private apiUrl = 'http://localhost:3000/api/food-items'; // Replace with your backend API endpoint

  constructor(private http: HttpClient) {}

  // Define the `getFoodItems` method
  getFoodItems(): Observable<FoodItem[]> {
    return this.http.get<FoodItem[]>(this.apiUrl);
  }
}