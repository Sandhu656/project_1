import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {
  orders: any[] = []; // Array to store order history

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    const customerId = '12345'; // Replace with the logged-in customer's ID
    this.http.get<any[]>(`http://localhost:3000/api/orders/history?customerId=${customerId}`).subscribe(
      (data) => {
        this.orders = data; // Assign the data directly if it's an array
      },
      (error) => {
        console.error('Error fetching order history:', error);
      }
    );
  }
}