import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Review {
  _id?: string;
  userId: string;
  itemId: string;
  rating: number;
  comment?: string;
  createdAt?: string;
  likes: number;
}

@Injectable({
  providedIn: 'root',
})
export class ReviewService {
  private apiUrl = 'http://localhost:3000/api/reviews';

  constructor(private http: HttpClient) {}

  // Add a review
  addReview(review: Review): Observable<Review> {
    return this.http.post<Review>(this.apiUrl, review);
  }

  // Get reviews for a specific item
  getReviews(itemId: string): Observable<Review[]> {
    return this.http.get<Review[]>(`${this.apiUrl}/${itemId}`);
  }

  // Like a review
  likeReview(reviewId: string): Observable<Review> {
    return this.http.patch<Review>(`${this.apiUrl}/${reviewId}/like`, {});
  }
}