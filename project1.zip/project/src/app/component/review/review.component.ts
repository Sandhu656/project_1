import { Component, Input, OnInit } from '@angular/core';
import { ReviewService, Review } from 'src/app/review.service';

@Component({
  selector: 'app-reviews',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css'],
})
export class ReviewsComponent implements OnInit {
  @Input() itemId!: string; // ID of the food item
  reviews: Review[] = [];
  newReview: Review = {
    userId: '', // Set the logged-in user's ID here
    itemId: '',
    rating: 0,
    comment: '',
    likes: 0,
  };

  constructor(private reviewService: ReviewService) {}

  ngOnInit(): void {
    this.getReviews();
  }

  // Fetch reviews for the item
  getReviews(): void {
    this.reviewService.getReviews(this.itemId).subscribe((data) => {
      this.reviews = data;
    });
  }

  // Add a new review
  addReview(): void {
    this.newReview.itemId = this.itemId;
    this.reviewService.addReview(this.newReview).subscribe((data) => {
      this.reviews.unshift(data);
      this.newReview = { userId: '', itemId: '', rating: 0, comment: '', likes: 0 };
    });
  }

  // Like a review
  likeReview(reviewId: string): void {
    this.reviewService.likeReview(reviewId).subscribe((data) => {
      const review = this.reviews.find((r) => r._id === reviewId);
      if (review) {
        review.likes = data.likes;
      }
    });
  }
}