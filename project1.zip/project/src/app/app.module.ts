import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; // Import FormsModule

import { AppComponent } from './app.component';
import { FoodComponent } from './food/food.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { ReviewsComponent } from './component/review/review.component';

@NgModule({
  declarations: [
    AppComponent,
    FoodComponent,
    OrderHistoryComponent,
    ReviewsComponent, // Declare components here
  ],
  imports: [
    BrowserModule,
    FormsModule, // Import FormsModule here
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}