import { Component, OnInit } from '@angular/core';
import { FoodItem, FoodService } from '../service/food-items.service';

@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.css'],
})
export class FoodComponent implements OnInit {
  foodItems: FoodItem[] = [];
  searchQuery: string = '';
historicalOrders: any;
popularFoods: any;

  constructor(private foodService: FoodService) {}

  ngOnInit(): void {
    this.foodService.getFoodItems().subscribe(
      (data) => {
        this.foodItems = data;
      },
      (error) => {
        console.error('Error fetching food items:', error);
      }
    );
  }

  // Updated getter with correct naming
  get filteredFoodItems(): FoodItem[] {
    return this.foodItems.filter((item) =>
      item.name.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      item.restaurant.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      item.tags.some((tag) => tag.toLowerCase().includes(this.searchQuery.toLowerCase()))
    );
  }
}